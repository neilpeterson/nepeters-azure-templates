﻿# Mock code added only for testing purposes. Not to be used for production deployments.

This code is compiled with the application by explicitly including the location in the application `project.json`'s "code" node. 
It is automatically excluded from compilation of current project by its presence in the compiler\shared\** special folder.